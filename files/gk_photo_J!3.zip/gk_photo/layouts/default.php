<?php

/**
 *
 * Default view
 *
 * @version             1.0.0
 * @package             Gavern Framework
 * @copyright			Copyright (C) 2010 - 2011 GavickPro. All rights reserved.
 *               
 */
 
// No direct access.
defined('_JEXEC') or die;
//
$app = JFactory::getApplication();
$menu = $app->getMenu();
$user = JFactory::getUser();
// getting User ID
$userID = $user->get('id');
// getting params
$option = JRequest::getCmd('option', '');
$view = JRequest::getCmd('view', '');
// defines if com_users
define('GK_COM_USERS', $option == 'com_users' && ($view == 'login' || $view == 'registration'));
// other variables
$btn_login_text = ($userID == 0) ? JText::_('TPL_GK_LANG_LOGIN') : JText::_('TPL_GK_LANG_LOGOUT');
// make sure that the modal will be loaded
JHTML::_('behavior.modal');
//
$page_suffix_output .= $this->page_suffix;
$page_suffix_table = explode(' ', $page_suffix_output);
$tpl_page_suffix = $page_suffix_output != '' ? ' class="'.$page_suffix_output.'" ' : '';
$logo_image = $this->API->get('logo_image', '');
$logo_image = $this->API->URLbase() . $logo_image;
$logo_image_header = $this->API->get('logo_image_header', '');
$logo_image_header = $this->API->URLbase() . $logo_image_header;
$logo_text = $this->API->get('logo_text', '');
$logo_slogan = $this->API->get('logo_slogan', '');
// conditions
$content_layout = (($option == 'com_k2' || $option == 'com_content') && !($option == 'com_content' && $view == 'archive')) || ($option == 'com_contact' && $view == 'contact');
$single_item_layout = ($option == 'com_k2' && $view == 'item') || ($option == 'com_content' && $view == 'article'); 
$full_width_layout = (in_array('full-width', $page_suffix_table) || $content_layout) && !((in_array('no-full-width', $page_suffix_table) && !$single_item_layout));

?>
<!DOCTYPE html>
<html lang="<?php echo $this->APITPL->language; ?>">
<head>
	<?php $this->layout->addTouchIcon(); ?>
	<?php if(
			$this->browser->get('browser') == 'ie6' || 
			$this->browser->get('browser') == 'ie7' || 
			$this->browser->get('browser') == 'ie8' || 
			$this->browser->get('browser') == 'ie9'
		) : ?>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
	<?php endif; ?>
    <?php if($this->API->get('rwd', 1)) : ?>
    <meta name="viewport" content="initial-scale = 1.0, user-scalable = no">
	<?php else : ?>
	<meta name="viewport" content="width=<?php echo $this->API->get('template_width', 1900)+40; ?>">
	<?php endif; ?>
    <jdoc:include type="head" />
    <?php $this->layout->loadBlock('head'); ?>
	<?php $this->layout->loadBlock('cookielaw'); ?>
</head>
<body<?php echo $tpl_page_suffix; ?><?php if($this->browser->get("tablet") == true) echo ' data-tablet="true"'; ?><?php if($this->browser->get("mobile") == true) echo ' data-mobile="true"'; ?><?php $this->layout->generateLayoutWidths(); ?> data-smoothscroll="<?php echo $this->API->get('use_smoothscroll', '1'); ?>">
	<?php
	     // put Google Analytics code
	     echo $this->social->googleAnalyticsParser();
	?>
	
	<?php if ($this->browser->get('browser') == 'ie8' || $this->browser->get('browser') == 'ie7' || $this->browser->get('browser') == 'ie6') : ?>
	<!--[if lte IE 8]>
	<div id="ie-toolbar"><div><?php echo JText::_('TPL_GK_LANG_IE_TOOLBAR'); ?></div></div>
	<![endif]-->
	<?php endif; ?>

	<div id="gk-bg" class="gk-clearfix">
	    <div id="gk-bg-wrap">
			<?php if(count($app->getMessageQueue())) : ?>
			<jdoc:include type="message" />
			<?php endif; ?>
			
			<?php if(count($this->API->modules('header'))) : ?>
			<div id="gk-header" class="gk-clearfix">
				<?php if($this->getLogoOverride()) : ?>
					<?php if($logo_image_header != '') : ?>
					<div class="gk-logo-wrap gk-page gk-half-page">
						<a href="<?php echo JURI::root(); ?>" class="gk-logo inverse">
							<img src="<?php echo $logo_image_header; ?>" alt="<?php echo JText::_('TPL_GK_LANG_HOMEPAGE'); ?>" />
						</a>
					</div>
					<?php elseif($logo_text != '') : ?>
					<div class="gk-logo-wrap gk-half-page">
						<div class="gk-page">
							<a href="<?php echo JURI::root(); ?>" class="gk-logo-text inverse">
								<span><?php echo $logo_text; ?></span>
								<?php if($logo_slogan != '') : ?>
								<span><?php echo $logo_slogan; ?></span>
								<?php endif; ?>
							</a>
						</div>
					</div>
					<?php endif; ?>
				<?php endif; ?>
				
				<jdoc:include type="modules" name="header" style="none" />
			</div>
			<?php endif; ?>
			
			<?php if(!in_array('no-mainbody', $page_suffix_table)) : ?>
			<div id="gk-content-wrap"<?php if(!$full_width_layout) : ?> class="gk-page"<?php endif; ?>>
				<?php if(($this->API->modules('breadcrumb') || $this->API->get('login_url', '') != '') && !$single_item_layout) : ?>
				<div id="gk-breadcrumb" class="gk-half-page">
					<?php if($this->API->get('login_url', '') != '') : ?>
					<a href="<?php echo $this->API->get('login_url', ''); ?>" id="gk-btn-login" class="button"><?php echo $userID > 0 ? JText::_('TPL_GK_LANG_LOGOUT') : JText::_('TPL_GK_LANG_LOGIN'); ?></a>
					<?php endif; ?>
					
					<?php if($this->API->modules('breadcrumb')) : ?>
					<jdoc:include type="modules" name="breadcrumb" style="none" />
					<?php endif; ?>
				</div>
				<?php endif; ?>
				
				<div id="gk-content"<?php if((!($this->API->modules('breadcrumb') && !$single_item_layout) && !$single_item_layout) || ($this->API->modules('top') && !$this->API->modules('breadcrumb'))) : ?> class="no-breadcrumb"<?php endif; ?>>				
					<?php if($this->API->modules('top')) : ?>
					<section id="gk-top" class="gk-cols3 gk-page">
						<div <?php if(isset($this->module_ids['top'])) echo ' id="'.$this->module_ids['top'].'"'; ?>>
							<jdoc:include type="modules" name="top" style="gk_style" modnum="<?php echo $this->API->modules('top') > 3 ? 3 : $this->API->modules('top'); ?>" />
						</div>
					</section>
					<?php endif; ?>
					
					<section id="gk-mainbody">
						<div<?php if(isset($this->module_ids['mainbody'])) echo ' id="'.$this->module_ids['mainbody'].'"'; ?>>
						<?php if(!$this->API->modules('mainbody')) : ?>
							<jdoc:include type="component" />
						<?php else : ?>
							<jdoc:include type="modules" name="mainbody" style="gk_style" />
						<?php endif; ?>
						</div>
					</section>
					
					<?php if($this->API->modules('bottom1')) : ?>
					<section id="gk-bottom1" class="gk-cols3 gk-page">
						<div <?php if(isset($this->module_ids['bottom1'])) echo ' id="'.$this->module_ids['bottom1'].'"'; ?>>
							<jdoc:include type="modules" name="bottom1" style="gk_style" modnum="<?php echo $this->API->modules('bottom1') > 3 ? 3 : $this->API->modules('bottom1'); ?>" />
						</div>
					</section>
					<?php endif; ?>
					
					<?php if($this->API->modules('bottom2')) : ?>
					<section id="gk-bottom2" class="gk-cols3 gk-page">
						<div <?php if(isset($this->module_ids['bottom2'])) echo ' id="'.$this->module_ids['bottom2'].'"'; ?>>
							<jdoc:include type="modules" name="bottom2" style="gk_style" modnum="<?php echo $this->API->modules('bottom2') > 3 ? 3 : $this->API->modules('bottom2'); ?>" />
						</div>
					</section>
					<?php endif; ?>
				</div>
				
				<?php if($this->API->modules('sidebar') && !$full_width_layout) : ?>
				<aside id="gk-sidebar" data-pos="<?php echo $this->API->get('sidebar_position', 'right'); ?>">
					<div>
						<jdoc:include type="modules" name="sidebar" style="gk_style" />
					</div>
				</aside>
				<?php endif; ?>
			</div>
			<?php endif; ?>
		</div>
    </div>
   	
   	<div id="page-nav" <?php if($this->API->get('stylearea', '0') == '0') : ?> class="gk-small-height"<?php endif; ?>>
	   	<div class="gk-page">
		   	<nav id="overlay-menu">
			    <?php if($logo_image != '') : ?>
			    <a href="<?php echo JURI::root(); ?>" class="gk-logo">
			    	<img src="<?php echo $logo_image; ?>" alt="<?php echo JText::_('TPL_GK_LANG_HOMEPAGE'); ?>" />
			    </a>
			    <?php elseif($logo_text != '') : ?>
				<a href="<?php echo JURI::root(); ?>" class="gk-logo-text">
					<span><?php echo $logo_text; ?></span>
					<?php if($logo_slogan != '') : ?>
					<span><?php echo $logo_slogan; ?></span>
					<?php endif; ?>
				</a>
				<?php endif; ?>
					
				<span id="gk-menu-button"><strong><?php echo JText::_('TPL_GK_LANG_OPEN_MENU'); ?></strong><span data-text="<?php echo JText::_('TPL_GK_LANG_CLOSE'); ?>"><?php echo JText::_('TPL_GK_LANG_MENU'); ?></span></span>
		   		
		   		<?php if($this->API->modules('social')) : ?>
		   		<div id="gk-social">
		   			<jdoc:include type="modules" name="social" style="none" />
		   		</div>
		   		<?php endif; ?>
		   	</nav>
		   	
		   	<footer id="gk-footer">
				<?php if(
					$this->API->modules('copyrigths') &&
					$this->API->get('stylearea', '0') == '1'
				) : ?>
				<div id="gk-style-area">
					<a href="#" id="gk-color1"><?php echo JText::_('TPL_GK_LANG_COLOR_1'); ?></a>
					<a href="#" id="gk-color2"><?php echo JText::_('TPL_GK_LANG_COLOR_2'); ?></a> 
					<a href="#" id="gk-color3"><?php echo JText::_('TPL_GK_LANG_COLOR_3'); ?></a>
					<a href="#" id="gk-color4"><?php echo JText::_('TPL_GK_LANG_COLOR_4'); ?></a>
					<a href="#" id="gk-color5"><?php echo JText::_('TPL_GK_LANG_COLOR_5'); ?></a>
				</div>
				<?php endif; ?>
				
				<?php if($this->API->modules('lang')) : ?>
				<div id="gk-lang">
					<jdoc:include type="modules" name="lang" style="gk_style" />
				</div>
				<?php endif; ?>
				
				<?php if($this->API->modules('copyrigths')) : ?>
				<div id="gk-copyrights">
					<jdoc:include type="modules" name="copyrigths" style="none" />
				</div>
				<?php endif; ?>
		   	</footer>
		</div>
   	</div>
   	
   	<div id="overlay-menu-content">  
   		<div id="overlay-menu-content-wrap1" class="gk-page">
			<div id="overlay-menu-content-wrap2" class="overthrow">
			<?php
				$this->asidemenu->loadMenu($this->API->get('menu_name','mainmenu')); 
				$this->asidemenu->genMenu($this->API->get('startlevel', 0), $this->API->get('endlevel',-1));
			?>
			</div>
		</div>
	</div>
   	
   	<?php $this->layout->loadBlock('tools/login'); ?>
   	<?php $this->layout->loadBlock('social'); ?>
   		
	<script>
		if(window.getSize().x > 600) {			
			window.sr = new scrollReveal();
		}
		
		jQuery(document).ready(function(){
		    // Target your .container, .wrapper, .post, etc.
		    jQuery("#gk-bg").fitVids();
		});
		
		jQuery("div.lazy").lazyload({
		     effect : "fadeIn"
		});
	</script>
	
	<jdoc:include type="modules" name="debug" />
</body>
</html>