// Google maps function
var gkMapInitialize = function() {
  var maps = jQuery('.gk-map');
  var mapCenters = [];
  var mapAreas = [];
  
  maps.each(function(i, map) {
  	map = jQuery(map);
	mapCenters[i] = new google.maps.LatLng(0.0, 0.0);
	  
	  
	if(map.data('latitude') !== undefined && map.data('longitude') !== undefined) {
		mapCenters[i] = new google.maps.LatLng(
	  		parseFloat(map.data('latitude')), 
	  		parseFloat(map.data('longitude'))
	  	);
	}
	  
	  
	  var mapOptions = {
	    scrollwheel: false,
	    zoom: parseInt(map.data('zoom'), 10) || 12,
	    center: mapCenters[i],
	    panControl: map.data('ui') === 'yes' ? true : false,
	    zoomControl: map.data('ui') === 'yes' ? true : false,
	    scaleControl: map.data('ui') === 'yes' ? true : false,
	    disableDefaultUI: map.data('ui') === 'yes' ? false : true,
	    mapTypeControl: map.data('ui') === 'yes' ? true : false,
        mapTypeControlOptions: {
            style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
            position: google.maps.ControlPosition.TOP_CENTER
        }
	  };
	
	  mapAreas[i] = new google.maps.Map(map.get(0), mapOptions);
	  var link = jQuery('<a>', { class: 'gk-map-close'});
	  link.insertAfter(map);
	  // custom events for the full-screen display
	  var marker = null;
	  map.on('displaybigmap', function() {
	  	marker = new google.maps.Marker({
	  	   position: mapCenters[i],
	  	   map: mapAreas[i],
	  	   animation: google.maps.Animation.DROP
	  	});
	  	
	  	setTimeout(function() {
	  		google.maps.event.trigger(mapAreas[i], 'resize');
	  	}, 300);
	  	
	  	mapAreas[i].setCenter(mapCenters[i]);
	  	
	  	if(map.data('line') !== undefined) {
	  		var points = map.data('line').split(';');
	  		var polyline = [];
	  		
	  		points = points.filter(function(x) { 
	  			return x != '';
	  		});
	  		
	  		jQuery.each(points, function(i, item) {
	  			var coords = item.split(',');
	  			polyline.push(new google.maps.LatLng(parseFloat(coords[0]), parseFloat(coords[1])));
	  		});
	  		
	  		if(points.length) {
	  			var path = new google.maps.Polyline({
	  				path: polyline,
	  				geodesic: true,
	  				strokeColor: '#ff0000',
	  				strokeOpacity: 1.0,
	  				strokeWeight: 2
	  			});
	  			
	  			path.setMap(mapAreas[i]);
	  		}
	  	}
	  });
	  
	  if(maps[i].hasClass('static')) {
	  	marker = new google.maps.Marker({
	  	   position: mapCenters[i],
	  	   map: mapAreas[i],
	  	   animation: google.maps.Animation.DROP
	  	});
	  }
	  
	  map.on('hidebigmap', function() {
	  	if(marker) {
	  		marker.setMap(null);
	  	}
	  });
  });
  
  jQuery(window).resize(function() {
  	mapAreas.each(function(map, i) {
  		map.setCenter(mapCenters[i]);
  	});
  });
};

(function($) {
	$(document).ready(function() {
		if($(document.body).attr('data-smoothscroll') == '1') {
			// smooth anchor scrolling
			$('a[href*="#"]').on('click', function (e) {
		        e.preventDefault();
		        if(this.hash !== '') {
		            var target = $(this.hash);

		            if(this.hash !== '' && this.href.replace(this.hash, '') == window.location.href.replace(window.location.hash, '')) {    
		                if(target.length && this.hash !== '#') {
		                    $('html, body').stop().animate({
		                        'scrollTop': target.offset().top
		                    }, 1000, 'swing', function () {
		                        if(this.hash !== '#') {
		                            window.location.hash = target.selector;
		                        }
		                    });
		                } else if(this.hash !== '' && this.href.replace(this.hash, '') !== '') {
		                    window.location.href = this.href;
		                }
		            } else if(this.hash !== '' && this.href.replace(this.hash, '') !== '') {
		                window.location.href = this.href;
		            }
		        }
		    });
		}
	    
	    // Google Maps loading
    	var loadScript = function() {
    		$.getScript("https://maps.googleapis.com/maps/api/js?v=3.exp&callback=gkMapInitialize")
    		  .fail(function( jqxhr, settings, exception ) {
    		   console.log('Google Maps script not loaded');
    		});		
    	};
    	
    	if($('.gk-map').length > 0) {
    		loadScript();
    	}
		// style area
		if($('#gk-style-area').length){
			$('#gk-style-area').find('a').each(function(i, element){
				$(element).click(function(e){
					e.preventDefault();
					e.stopPropagation();
					changeStyle(i+1);
				});
			});
		}
		// K2 font-size switcher fix
		if($('#fontIncrease').length > 0 && $('.itemIntroText').length > 0) {
			$('#fontIncrease').click(function() {
				$('.itemIntroText').attr('class', 'itemIntroText largerFontSize');
			});
			
			$('#fontDecrease').click( function() {
				$('.itemIntroText').attr('class', 'itemIntroText smallerFontSize');
			});
		}
		// Single item featured image
		if(
			($('#k2Container').hasClass('single-page') && $('#k2Container').children('.header').length) ||
			($('#comContentContainer').hasClass('single-page') && $('#comContentContainer').children('.header').length)
		) {
			var header = [];
			if($('#k2Container').length) {
				header = $('#k2Container').children('.header');
			} else {
				header = $('#comContentContainer').children('.header');
			}
			
			if(header.length) {
				$(window).scroll(function() {
					var h = header.outerHeight();
					var y = $(window).scrollTop();
					if(y <= h) {
						var progress = (y / h);
						header.css('background-position', 'center ' + (50 - (50 * progress)) + '%');
						var opacity = (100 - 90 * progress) / 100;
						header.css('opacity', opacity);
					}
				});
			}
		}
		
		// K2 portfolio
		if($('#k2Container').hasClass('portfolio') || $('#comContentContainer').hasClass('portfolio')) {
			var wrapper = $('#k2Container').length ? $('#k2Container') : $('#comContentContainer');
			var filter = wrapper.find('.item-filter');
			var items_wrapper = wrapper.find('.itemList');
			var tag_list = wrapper.find('ol');
			var tag_items = filter.find('li');
			var virtual_list = [];
			// move pagination
			if(wrapper.find('.pagination').length && $(window).outerWidth() > 640) {
				var pagination = wrapper.find('.pagination');
				$('#page-nav').find('.gk-page').before(pagination);
			}
			
			// fix for case when there is a lot of tags and only few items for display in the current selection
			wrapper.css('min-height', (tag_list.outerHeight() + 70) + "px");
			
			wrapper.find('.itemView').each(function(i, item) {
				item = $(item);
				var overlay = $('<a href="'+item.attr('data-link')+'" class="gk-overlay"><span></span></a>');
			
				if(wrapper.hasClass('blog-grid')) {
					var overlay = $('<a href="'+item.attr('data-link')+'" class="gk-overlay"><strong>'+item.attr('data-text')+'</strong></a>');
				}
				item.find('.itemImageBlock').append(overlay);
				// create virtual list of nodes
				var copy = item.clone(true, true);
				copy.attr('class', 'itemView');
				virtual_list.push(copy[0]);
			});
			
			if(filter.length) {
				filter.click(function() {				
					if(!$(this).hasClass('gk-active')) {
						$(this).addClass('gk-active');
						$(this).find('ol').addClass('gk-show');
						
						var list = $(this).find('ol');
						list.find('li').each(function(i, li) {
							setTimeout(function() {
								if(list.hasClass('gk-show')) {
									li.addClass('gk-active');
								}
							}, i * 50);
						});
					} else {
						var self = this;
						setTimeout(function() {
							self.removeClass('gk-active');
						}, 300);
						$(this).find('ol').removeClass('gk-show');
						$(this).find('ol li').removeClass('gk-active');
					}
				});
				
				tag_items.click(function() {
					var id = $(this).attr('data-value');
					var name = $(this).text();
					var items = wrapper.find('.itemView');
					// update label
					$('#item-filter-selected').text(name);
					// show filtered items
					if(id !== '') {
						items.removeClass('gk-active');
						items.addClass('gk-hide');
						
						setTimeout(function() {
							// remove all items
							items.remove();
							// create list of new items
							virtual_list.each(function(item, i) {
								item = $(item);
								
								var item_tags = item.attr('data-tags') || '';
								if(item_tags != '') {
									item_tags.split(' ');
								}
								
								if(item_tags.indexOf(id) !== -1) {
									var copy = item.clone(true, true);
									items_wrapper.append(copy);
									setTimeout(function() {
										copy.addClass('gk-active');
									}, 100);
								}
							});
							// activate lazy load
							jQuery("div.lazy").lazyload({
							     effect : "fadeIn"
							});
						}, 350);
					} else {
						items.removeClass('gk-active');
						items.addClass('gk-active');
						
						setTimeout(function() {
							// remove all items
							items.remove();
							// create list of new items
							virtual_list.each(function(item, i) {
								item = $(item);
								var copy = item.clone(true, true);
								items_wrapper.append(copy);
								setTimeout(function() {
									copy.addClass('gk-active');
								}, 100);
							});
							// activate lazy load
							jQuery("div.lazy").lazyload({
							     effect : "fadeIn"
							});
						}, 350);
					}
				});
			}
		}
	});
	
	// Function to change styles
	function changeStyle(style){
		// cookie function
		$.cookie = function (key, value, options) {
	    // key and at least value given, set cookie...
	    if (arguments.length > 1 && String(value) !== "[object Object]") {
	        options = $.extend({}, options);
	        if (value === null || value === undefined) {
	            options.expires = -1;
	        }
	        if (typeof options.expires === 'number') {
	            var days = options.expires, t = options.expires = new Date();
	            t.setDate(t.getDate() + days);
	        }
	
	        value = String(value);
	
	        return (document.cookie = [
	            encodeURIComponent(key), '=',
	            options.raw ? value : encodeURIComponent(value),
	            options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
	            options.path ? '; path=' + options.path : '',
	            options.domain ? '; domain=' + options.domain : '',
	            options.secure ? '; secure' : ''
	        ].join(''));
	    }
	    // key and possibly options given, get cookie...
	    options = value || {};
	    var result, decode = options.raw ? function (s) { return s; } : decodeURIComponent;
	    return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null;
		};
	
		var file1 = $GK_TMPL_URL+'/css/style'+style+'.css';
		var file2 = $GK_TMPL_URL+'/css/typography/typography.style'+style+'.css';
		$('head').append('<link rel="stylesheet" href="'+file1+'" type="text/css" />');
		$('head').append('<link rel="stylesheet" href="'+file2+'" type="text/css" />');
	
		$.cookie('gk_writer_j30_style', style, { expires: 365, path: '/' });
	}
})(jQuery);