<?php

// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT.'/helpers');

?>

<section id="comContentContainer" class="portfolio blog-grid blog<?php echo $this->pageclass_sfx;?>" itemscope itemtype="http://schema.org/Blog">
	<?php 
		if(
			$this->params->get('show_page_heading', 1) ||
			$this->params->get('show_category_title', 1) || 
			$this->params->get('page_subheading') ||
			(
				(
					$this->params->get('show_description', 1) || 
					$this->params->def('show_description_image', 1)
				)
				||
				(
					(
						$this->params->get('show_description_image') && 
						$this->category->getParams()->get('image')
					)
					||
					(
						$this->params->get('show_description') && 
						$this->category->description
					)
				)
			)
		) : 
	?>
	<div class="itemsCategory gk-page">
		<?php if ($this->params->get('show_page_heading', 1)) : ?>
		<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
		<?php endif; ?>
		
		<?php if ($this->params->get('show_category_title', 1)) : ?>
		<h2><?php echo $this->category->title;?></h2>
		<?php endif; ?>
		
		<?php if ($this->params->get('show_tags', 1) && !empty($this->category->tags->itemTags)) : ?>
		 	<span class="tags-label"><?php echo JText::sprintf('TPL_GK_LANG_TAGGED_UNDER'); ?></span>             
		 	<?php $this->category->tagLayout = new JLayoutFile('joomla.content.tags'); ?>
			<?php echo $this->category->tagLayout->render($this->category->tags->itemTags); ?>
		<?php endif; ?>
	</div>
	<?php endif; ?>
	
	<?php 
		$items = array();
		
		if (!empty($this->lead_items)) $items = array_merge($items, $this->lead_items);
		if (!empty($this->intro_items)) $items = array_merge($items, $this->intro_items);
	?>
	<div class="itemList" data-cols="<?php echo $this->columns; ?>">
		<?php foreach ($items as &$item) : ?>
	    <?php
			$this->item = &$item;
			echo $this->loadTemplate('item');
		?>
		<?php endforeach; ?>
	</div>
	
	<?php if (
		($this->params->def('show_pagination', 1) == 1  || $this->params->get('show_pagination') == 2) && 
		$this->pagination->get('pages.total') > 1
	) : ?>
	<?php echo $this->pagination->getPagesLinks(); ?>
	<?php endif; ?>
</section>
