<?php

// no direct access
defined('_JEXEC') or die;

// Create a shortcut for params.
$params = &$this->item->params;
$images = json_decode($this->item->images);
$canEdit	= $this->item->params->get('access-edit');

$item_url = JRoute::_(ContentHelperRoute::getArticleRoute($this->item->slug, $this->item->catid, $this->item->language));

$bg = ' no-image'; 

if(isset($images->image_intro) && !empty($images->image_intro)) {
	$bg = ' lazy" data-original="' . JURI::root() . $images->image_intro . '';
} else if(isset($images->image_fulltext) && !empty($images->image_fulltext)) {
	$bg = ' lazy" data-original="' . JURI::root() . $images->image_fulltext . '';
}

?>

<article class="itemView gk-active" data-link="<?php echo $item_url; ?>" data-text="<?php echo JText::_('TPL_GK_LANG_READ_MORE'); ?>" itemprop="blogPost" itemscope itemtype="http://schema.org/BlogPosting">
	<div class="itemImageBlock<?php echo $bg; ?>">
		<div class="itemInfo">
			<?php if($params->get('show_author') && !empty($this->item->author)): ?>
				<?php 
					$author_obj = JFactory::getUser($this->item->created_by);
					$author_email = $author_obj->email;
					$author_name = $this->item->created_by_alias ? $this->item->created_by_alias : $this->item->author;
					$gravatar_url = "//www.gravatar.com/avatar/" . md5( strtolower( trim( $author_email ) ) ) . ".jpg?s=120";
				?>
				
				<?php
					$cntlink = '';
					
					if (!empty($this->item->contactid) && $params->get('link_author') == true) {
						$needle = 'index.php?option=com_contact&view=contact&id=' . $this->item->contactid;
						$menu = JFactory::getApplication()->getMenu();
						$item = $menu->getItems('link', $needle, true);
						$cntlink = !empty($item) ? $needle . '&Itemid=' . $item->id : $needle;
					}
				?>
				<?php if($cntlink != '') : ?><a href="<?php echo $cntlink; ?>"><?php endif; ?>
				<img src="<?php echo $gravatar_url; ?>" title="<?php echo $author_name; ?>" alt="<?php echo $author_name; ?>" />
				<?php if($cntlink != '') : ?></a><?php endif; ?>
			<?php endif; ?>
			
			<?php if($params->get('show_publish_date')) : ?>
			<time datetime="<?php echo JHtml::_('date', $this->item->publish_up, JText::_(DATE_W3C)); ?>" itemprop="datePublished">
				<?php echo JHTML::_('date', $this->item->publish_up, 'd.m.Y'); ?>
			</time>
			<?php elseif($params->get('show_create_date')) : ?>
			<time datetime="<?php echo JHtml::_('date', $this->item->created, JText::_(DATE_W3C)); ?>" itemprop="dateCreated">
				<?php echo JHTML::_('date', $this->item->created, 'd.m.Y'); ?>
			</time>
			<?php endif; ?>
			
			<?php if ($params->get('show_title')) : ?>
			<h3 itemprop="name">
				<?php if ($params->get('link_titles') && $params->get('access-view')) : ?>
					<a href="<?php echo JRoute::_(ContentHelperRoute::getArticleRoute($this->item->slug, $this->item->catid, $this->item->language)); ?>">
					<?php echo $this->escape($this->item->title); ?></a>
				<?php else : ?>
					<?php echo $this->escape($this->item->title); ?>
				<?php endif; ?>
			</h3>
			<?php endif; ?>		
		</div>
	</div>
</article>

<?php echo $this->item->event->afterDisplayContent; ?>