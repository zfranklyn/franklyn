<?php

// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers');

?>

<section id="comContentContainer" class="portfolio blog-grid<?php echo $this->pageclass_sfx;?>" itemscope itemtype="http://schema.org/Blog">
      <?php if( $this->params->get('show_page_heading') != 0 ) : ?>
      <div class="gk-page">
           <h2><?php echo $this->escape($this->params->get('page_heading')); ?></h2>
      </div>
      <?php endif; ?>
      
      <?php 
      	$items = array();
      	
      	if (!empty($this->lead_items)) $items = array_merge($items, $this->lead_items);
      	if (!empty($this->intro_items)) $items = array_merge($items, $this->intro_items);
      ?>
      <div class="itemList" data-cols="<?php echo $this->columns; ?>">
      	<?php foreach ($items as &$item) : ?>
          <?php
      		$this->item = &$item;
      		echo $this->loadTemplate('item');
      	?>
      	<?php endforeach; ?>
      </div>
      
      <?php if ($this->params->def('show_pagination', 2) == 1  || ($this->params->get('show_pagination') == 2 && $this->pagination->get('pages.total') > 1)) : ?>
      <?php echo $this->pagination->getPagesLinks(); ?>
      <?php endif; ?>
</section>
