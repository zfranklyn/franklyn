<?php

/**
 * @package		K2
 * @author		GavickPro http://gavick.com
 */

// no direct access
defined('_JEXEC') or die;

// Get user stuff (do not change)
$user = JFactory::getUser();

?>

<section id="k2Container" class="portfolio portfolio-grid userView<?php if($this->params->get('pageclass_sfx')) echo ' '.$this->params->get('pageclass_sfx'); ?>">
     <?php if($this->params->get('show_page_title') && $this->params->get('page_title')!=$this->user->name): ?>
     <div class="gk-page">
          <h2><?php echo $this->escape($this->params->get('page_title')); ?></h2>
     </div>
     <?php endif; ?>
     <?php if ($this->params->get('userImage') || $this->params->get('userName') || $this->params->get('userDescription') || $this->params->get('userURL') || $this->params->get('userEmail')): ?>
     <div class="itemAuthorData gk-page">
          <?php if ($this->params->get('userName')): ?>
          <h3><?php echo $this->user->name; ?></h3>
          <?php endif; ?>
          <div class="itemAuthorDetails">
               <?php if ($this->params->get('userDescription') && isset($this->user->profile->description)): ?>
               <p><?php echo $this->user->profile->description; ?></p>
               <?php endif; ?>
               <p>
                    <?php if ($this->params->get('userEmail')): ?>
                    <?php echo JText::_('K2_EMAIL'); ?>: <?php echo JHTML::_('Email.cloak', $this->user->email); ?>
                    <?php endif; ?>
                    <?php if ($this->params->get('userURL') && isset($this->user->profile->url) && trim($this->user->profile->url) != ''): ?>
                    <?php echo JText::_('K2_WEBSITE_URL'); ?>: <a href="<?php echo $this->user->profile->url; ?>" target="_blank" rel="me"><?php echo $this->user->profile->url; ?></a>
                    <?php endif; ?>
               </p>
          </div>
          <?php if ($this->params->get('userImage') && !empty($this->user->avatar)): ?>
          <img src="<?php echo $this->user->avatar; ?>" alt="<?php echo $this->user->name; ?>"  />
          <?php endif; ?>
          <?php echo $this->user->event->K2UserDisplay; ?> </div>
     <?php endif; ?>
     <?php if(count($this->items)): ?>
     <div class="itemList" data-cols="2">
          <?php foreach ($this->items as $item): ?>
          <article class="itemView gk-active" data-link="<?php echo $item->link; ?>" data-text="<?php echo JText::_('TPL_GK_LANG_READ_MORE'); ?>"> <?php echo $item->event->BeforeDisplay; ?> <?php echo $item->event->K2BeforeDisplay; ?>
               <?php 
                		$bg = ' no-image';
                		
                		if($item->imageLarge) {
                			$bg = ' lazy" data-original="' . $item->imageLarge . '';
                		}
                	?>
               <div class="itemImageBlock<?php echo $bg; ?>">
                    <div class="itemInfo">
                         <?php if($item->params->get('userItemTitle')): ?>
                         <h2>
                              <?php
                              	$title = explode('--', $item->title);
                              	$title_part_one = $title[0];
                              	
                              	if(isset($title[1])) {
                              		$title_part_two = '<small>' . $title[1] . '</small>';
                              	}
                              	
                              	$title = $title_part_one . $title_part_two;
                              ?>
                              <?php if ($item->params->get('userItemTitleLinked')): ?>
                              <a href="<?php echo $item->link; ?>"><?php echo $title; ?></a>
                              <?php else: ?>
                              <?php echo $title; ?>
                              <?php endif; ?>
                         </h2>
                         <?php endif; ?>
                    </div>
               </div>
               <?php echo $item->event->AfterDisplay; ?> <?php echo $item->event->K2AfterDisplay; ?> </article>
          <?php endforeach; ?>
     </div>
     <?php if($this->params->get('userFeedIcon',1)): ?>
     <a class="k2FeedIcon" href="<?php echo $this->feed; ?>"><?php echo JText::_('K2_SUBSCRIBE_TO_THIS_RSS_FEED'); ?></a>
     <?php endif; ?>
     <?php if(count($this->pagination->getPagesLinks())): ?>
     <?php echo $this->pagination->getPagesLinks(); ?>
     <?php endif; ?>
     <?php endif; ?>
</section>
