<?php

/**
 * @package		K2
 * @author		GavickPro http://gavick.com
 */

// no direct access
defined('_JEXEC') or die;

$bg = '';

if($this->item->image) {
	$bg = ' lazy" data-original="' . $this->item->image . '';
} else {
	$bg = ' no-image'; 
}

?>

<article class="itemView gk-active" data-link="<?php echo $this->item->link; ?>" data-text="<?php echo JText::_('TPL_GK_LANG_READ_MORE'); ?>">          
    <div class="itemImageBlock<?php echo $bg; ?>">
		<?php if($this->item->featured): ?>
		 <sup><i class="gk-icon-star"></i></sup>
		<?php endif; ?>
			
		<div class="itemInfo">
		    <?php if($this->item->params->get('latestItemDateCreated')): ?>
		    <time datetime="<?php echo JHtml::_('date', $this->item->created, JText::_(DATE_W3C)); ?>"> <?php echo JHTML::_('date', $this->item->created, JText::_('j.m.Y')); ?> </time>
		    <?php endif; ?>
		    
		    <?php if($this->item->params->get('latestItemTitle')): ?>
	    	<h2>
	            <?php if ($this->item->params->get('latestItemTitleLinked')): ?>
	            <a href="<?php echo $this->item->link; ?>"><?php echo $this->item->title; ?></a>
	            <?php else: ?>
	            <?php echo $this->item->title; ?>
	            <?php endif; ?>
	    	</h2>
		    <?php endif; ?>    
		</div>
	</div>
</article>