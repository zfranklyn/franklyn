<?php

/**
 * @package		K2
 * @author		GavickPro http://gavick.com
 */

// no direct access
defined('_JEXEC') or die;

?>

<section id="k2Container" class="portfolio blog-grid<?php if($this->params->get('pageclass_sfx')) echo ' '.$this->params->get('pageclass_sfx'); ?>">
	<?php if($this->params->get('show_page_title')): ?>
	<div class="gk-page">
		<h2><?php echo $this->escape($this->params->get('page_title')); ?></h2>
	</div>
	<?php endif; ?>
	
	<div class="itemList" data-cols="<?php echo $this->params->get('latestItemsCols'); ?>">
		<?php foreach($this->blocks as $key=>$block): ?>
			<?php foreach ($block->items as $item): K2HelperUtilities::setDefaultImage($item, 'latest', $this->params); ?>
				<?php $this->item=$item; echo $this->loadTemplate('item'); ?>
			<?php endforeach; ?>
		<?php endforeach; ?>
	</div>
</section>
