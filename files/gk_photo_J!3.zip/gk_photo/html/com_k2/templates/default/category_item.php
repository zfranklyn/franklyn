<?php

/**
 * @package		K2
 * @author		GavickPro http://gavick.com
 */

// no direct access
defined('_JEXEC') or die;

// Define default image size (do not change)
K2HelperUtilities::setDefaultImage($this->item, 'itemlist', $this->params);

$tag_ids = '';

if(count($this->item->tags)) {
	foreach($this->item->tags as $tag) {
		$tag_ids .= ' ' . $tag->id;
	}
}

$bg = '';

if($this->item->image) {
	$bg = ' lazy" data-original="' . $this->item->image . '';
} else {
	$bg = ' no-image'; 
}

?>

<article class="itemView gk-active" data-tags="<?php echo $tag_ids; ?>" data-link="<?php echo $this->item->link; ?>" data-text="<?php echo JText::_('TPL_GK_LANG_READ_MORE'); ?>"> 	
	<?php echo $this->item->event->BeforeDisplay; ?> 
	<?php echo $this->item->event->K2BeforeDisplay; ?>
	
	<div class="itemImageBlock<?php echo $bg; ?>">
        <?php if($this->item->featured): ?>
        <sup><i class="gk-icon-star"></i></sup>
        <?php endif; ?>
	    
	    <div class="itemInfo">
		    <?php if($this->item->params->get('catItemAuthor')): ?>
		        <?php if(isset($this->item->author->link) && $this->item->author->link): ?>
		        	<a rel="author" href="<?php echo $this->item->author->link; ?>" title="<?php echo $this->item->author->name; ?>">
		        		<img src="<?php echo $this->item->author->avatar; ?>" alt="<?php echo $this->item->author->name; ?>" />
		        	</a>
		        <?php else: ?>
		        	<img src="<?php echo $this->item->author->avatar; ?>" alt="<?php echo $this->item->author->name; ?>" />
		        <?php endif; ?>
		    <?php endif; ?>
		    
		    <?php if($this->item->params->get('catItemDateCreated')): ?>
		    <time datetime="<?php echo JHtml::_('date', $this->item->created, JText::_(DATE_W3C)); ?>"> <?php echo JHTML::_('date', $this->item->created, JText::_('j.m.Y')); ?> </time>
		    <?php endif; ?>
		    
		    <?php if($this->item->params->get('catItemTitle')): ?>
		    	<h3>
		            <?php if ($this->item->params->get('catItemTitleLinked')): ?>
		            <a href="<?php echo $this->item->link; ?>"><?php echo $this->item->title; ?></a>
		            <?php else: ?>
		            <?php echo $this->item->title; ?>
		            <?php endif; ?>
		    	</h3>
		    	<?php echo $this->item->event->AfterDisplayTitle; ?> 
		    	<?php echo $this->item->event->K2AfterDisplayTitle; ?>
		    <?php endif; ?>    
	    </div>
	</div>

    <?php echo $this->item->event->AfterDisplay; ?> 
    <?php echo $this->item->event->K2AfterDisplay; ?>
</article>
