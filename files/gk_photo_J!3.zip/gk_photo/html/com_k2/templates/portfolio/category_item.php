<?php

/**
 * @package		K2
 * @author		GavickPro http://gavick.com
 */

// no direct access
defined('_JEXEC') or die;

// Define default image size (do not change)
K2HelperUtilities::setDefaultImage($this->item, 'itemlist', $this->params);

$tag_ids = '';

if(count($this->item->tags)) {
	foreach($this->item->tags as $tag) {
		$tag_ids .= ' ' . $tag->id;
	}
}

$bg = '';

if($this->item->image) {
	$bg = ' lazy" data-original="' . $this->item->image . '';
} else {
	$bg = ' no-image'; 
}

?>
<?php if($this->item->image) : ?>

<article class="itemView gk-active" data-tags="<?php echo $tag_ids; ?>" data-link="<?php echo $this->item->link; ?>">
     <div class="itemImageBlock<?php echo $bg; ?>"> <a class="itemImage" href="<?php echo $this->item->link; ?>" title="<?php if(!empty($this->item->image_caption)) echo K2HelperUtilities::cleanHtml($this->item->image_caption); else echo K2HelperUtilities::cleanHtml($this->item->title); ?>"> <img src="<?php echo $this->item->image; ?>" alt="<?php if(!empty($this->item->image_caption)) echo K2HelperUtilities::cleanHtml($this->item->image_caption); else echo K2HelperUtilities::cleanHtml($this->item->title); ?>" style="width:<?php echo $this->item->imageWidth; ?>px; height:auto;" /> </a>
          <?php if($this->item->featured): ?>
          <sup><i class="gk-icon-star"></i></sup>
          <?php endif; ?>
     </div>
</article>
<?php endif; ?>
