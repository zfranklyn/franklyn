<?php

/**
 * @package		K2
 * @author		GavickPro http://gavick.com
 */

// no direct access
defined('_JEXEC') or die;

?>

<div id="k2Container" class="portfolio portfolio-grid <?php if($this->params->get('pageclass_sfx')) echo ' '.$this->params->get('pageclass_sfx'); ?><?php if(!$this->params->get('show_page_title')): ?> no-breadcrumb-space<?php endif; ?>">
	<div class="gk-page">
		<?php if($this->params->get('show_page_title')): ?>
		<h2 class="componentheading"><?php echo $this->escape($this->params->get('page_title')); ?></h2>
		<?php endif; ?>
	          
		<?php 
			$items = array();
			
			if(isset($this->leading)) $items = array_merge($items, $this->leading);	
			if(isset($this->primary)) $items = array_merge($items, $this->primary);			
			if(isset($this->secondary)) $items = array_merge($items, $this->secondary);	
		
			if(count($items)): 
		?>
		<?php
			$tags = array();
			
			foreach($items as $item) {
				$item_tags = $item->tags;
				
				foreach($item_tags as $tag) {
					if(!isset($tags[$tag->id])) {
						$tags[$tag->id] = $tag->name;
					}
				}
			}
			
			asort($tags);
		?>
		
		<div class="item-filter gk-half-page">
			<?php echo JText::_('TPL_GK_LANG_FILTER'); ?> <strong id="item-filter-selected" data-value=""><?php echo JText::_('TPL_GK_LANG_ALL'); ?></strong>
			
			<ol id="item-filter-dropdown">
				<li data-value=""><?php echo JText::_('TPL_GK_LANG_ALL'); ?></li>
				<?php foreach($tags as $tag_id => $tag_name) : ?>
				<li data-value="<?php echo $tag_id; ?>"><?php echo $tag_name; ?></li>
				<?php endforeach; ?>
			</ol>
		</div>
	</div>
	
    <div class="itemList" data-cols="<?php echo $this->params->get('num_leading_columns'); ?>">
    	<?php foreach($items as $item): ?>
			<?php
				$this->item = $item;
				echo $this->loadTemplate('item');
			?>
         <?php endforeach; ?>
    </div>
    
    <?php if(count($this->pagination->getPagesLinks())): ?>
        <?php if($this->params->get('catPagination')): ?>
        	<?php echo $this->pagination->getPagesLinks(); ?>
        <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>
</div>
