<?php

/**
 * @package		K2
 * @author		GavickPro http://gavick.com
 */

// no direct access
defined('_JEXEC') or die;

// Define default image size (do not change)
K2HelperUtilities::setDefaultImage($this->item, 'itemlist', $this->params);

$tag_ids = '';

if(count($this->item->tags)) {
	foreach($this->item->tags as $tag) {
		$tag_ids .= ' ' . $tag->id;
	}
}

$bg = '';

if($this->item->image) {
	$bg = ' lazy" data-original="' . $this->item->image . '';
} else {
	$bg = ' no-image'; 
}

?>

<article class="itemView gk-active" data-tags="<?php echo $tag_ids; ?>" data-link="<?php echo $this->item->link; ?>">
     <div class="itemImageBlock<?php echo $bg; ?>">
          <?php if($this->item->params->get('catItemTitle')): ?>
          <h2>
               <?php
				
					$title = explode('--', $this->item->title);
					$title_part_one = $title[0];
					
					if(isset($title[1])) {
						$title_part_two = '<small>' . $title[1] . '</small>';
					}
					
					$title = $title_part_one . $title_part_two;
					
			   ?>
               <?php if ($this->item->params->get('catItemTitleLinked')): ?>
               <a href="<?php echo $this->item->link; ?>"><?php echo $title; ?></a>
               <?php else: ?>
               <?php echo $title; ?>
               <?php endif; ?>
          </h2>
          <?php endif; ?>
          <?php if($this->item->featured): ?>
          <sup><i class="gk-icon-star"></i></sup>
          <?php endif; ?>
     </div>
</article>
